import com.sun.mail.imap.IMAPMessage;
import com.sun.mail.pop3.POP3Message;

import javax.mail.*;
import javax.mail.internet.MimeMessage;
import javax.mail.search.FlagTerm;
import java.io.IOException;
import java.util.Properties;

public class MailMain {
    public static final String USERNAME = "as-ga@42rg.ru";
    public static final String PASSWORD = "gj,tlfgj,tlf@";

    public static void main(String[] args) throws MessagingException, IOException {

        // 1. Setup properties for the mail session.
        Properties props = new Properties();
//        props.put("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
//        props.put("mail.pop3.socketFactory.fallback", "false");
//        props.put("mail.pop3.socketFactory.port", "995");
//        props.put("mail.pop3.port", "995");
//        props.put("mail.pop3.host", "imap.yandex.ru");
//        props.put("mail.pop3.user", MailMain.USERNAME);
//        props.put("mail.store.protocol", "imap");
        props.setProperty("mail.store.protocol", "imaps");
        props.setProperty("mail.imaps.ssl.trust", "imap.yandex.ru");
//        props.put("mail.pop3.ssl.protocols", "TLSv1.2");

        // 2. Creates a javax.mail.Authenticator object.
        Authenticator auth = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(MailMain.USERNAME, MailMain.PASSWORD);
            }
        };

        // 3. Creating mail session.
        Session session = Session.getDefaultInstance(props);

        // 4. Get the POP3 store provider and connect to the store.
        Store store = session.getStore();
        store.connect("imap.yandex.ru", 993, MailMain.USERNAME, MailMain.PASSWORD);

        // 5. Get folder and open the INBOX folder in the store.
        Folder inbox = store.getFolder("INBOX");
        inbox.open(Folder.READ_WRITE);

        // 6. Retrieve the messages from the folder.
        try {
            inbox.getMessageCount();
            Message lastMessage = inbox.getMessage(inbox.getMessageCount());
            ((IMAPMessage) lastMessage).setPeek(true); // this is how you prevent automatic SEEN flag
            MimeMessage cmsg = new MimeMessage((MimeMessage) lastMessage); // this is how you deal with exception "Unable to load BODYSTRUCTURE"
            printMessage(cmsg);
            markMessageAsSeen(lastMessage, inbox);
            FlagTerm unreadFlag = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
            Message unreadMessages[] = inbox.search(unreadFlag);
            for (Message unreadMessage : unreadMessages) {
                // SEEN flag here will be set automatically.
                printMessage(unreadMessage);
            }
            ((IMAPMessage) lastMessage).setFlag(Flags.Flag.DELETED, true);

        } finally {
            inbox.close(true);
        }
    }

    private static void printMessage(Message message) throws MessagingException, IOException {
        Address[] addresses = message.getFrom();
        for (Address address : addresses) {
            System.out.println("FROM: " + address.toString());
        }
        System.out.println("SUBJECT:" + message.getSubject());
        System.out.println("TEXT:" + getText(message).trim());
    }

    private static void markMessageAsSeen(Message message, Folder folder) throws MessagingException {
        folder.setFlags(new Message[]{message}, new Flags(Flags.Flag.SEEN), true);
    }

    private static boolean textIsHtml = false; // if test is html, use html parser (e.g. org.jsoup)

    // copy-paste from http://www.oracle.com/technetwork/java/javamail/faq/index.html#mainbody
    private static String getText(Part p) throws
            MessagingException, IOException {
        if (p.isMimeType("text/*")) {
            String s = (String) p.getContent();
            textIsHtml = p.isMimeType("text/html");
            return s;
        }
        if (p.isMimeType("multipart/alternative")) {
            // prefer html text over plain text
            Multipart mp = (Multipart) p.getContent();
            String text = null;
            for (int i = 0; i < mp.getCount(); i++) {
                Part bp = mp.getBodyPart(i);
                if (bp.isMimeType("text/plain")) {
                    if (text == null)
                        text = getText(bp);
                    continue;
                } else if (bp.isMimeType("text/html")) {
                    String s = getText(bp);
                    if (s != null)
                        return s;
                } else {
                    return getText(bp);
                }
            }
            return text;
        } else if (p.isMimeType("multipart/*")) {
            Multipart mp = (Multipart) p.getContent();
            for (int i = 0; i < mp.getCount(); i++) {
                String s = getText(mp.getBodyPart(i));
                if (s != null)
                    return s;
            }
        }
        return null;
    }
}
